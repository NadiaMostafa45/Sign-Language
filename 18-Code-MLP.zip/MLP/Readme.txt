TO RUN THE PROGRAM 

=>1.install the packedges mentioned on the requirements file.
=>2.run the collect_imgs file( if you want to retrain it.!!)
=>3.run the create_dataset file 
=>4.run the train_classifier file 
=>5.run the inference_classifier file 
